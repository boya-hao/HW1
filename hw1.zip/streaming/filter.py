import tweepy
import sys
import json
from textwrap import TextWrapper
from datetime import datetime
from elasticsearch import Elasticsearch, RequestsHttpConnection
from elasticsearch_dsl import Search

es = Elasticsearch(
  [
  'https://search-twitter-4gq7qku6bsxkouqneo3ktustqm.us-east-1.es.amazonaws.com'
  ],

  use_ssl=True,
  verify_certs=True,
  connection_class = RequestsHttpConnection

  )


s = es.search(
              index="hillary",
              body={
                "query":{
                  "filtered": {
                    "query":{
                      "match_all": {}
                    }

                  }
                },
                "filter": {
                  "exists": {"field": "coordinates"}
                }
              }
              )

          
for hit in s['hits']['hits']:
  es.create(index="hillaryn",
          doc_type="twitter_filter",
          body=hit['_source']
          )



s = es.search(
              index="trump",
              body={
                "query":{
                  "filtered": {
                    "query":{
                      "match_all": {}
                    }

                  }
                },
                "filter": {
                  "exists": {"field": "coordinates"}
                }
              }
              )

          
for hit in s['hits']['hits']:
  es.create(index="trumpn",
          doc_type="twitter_filter",
          body=hit['_source']
          )

