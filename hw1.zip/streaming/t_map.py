import tweepy
import sys
import json
from textwrap import TextWrapper
from datetime import datetime
from elasticsearch import Elasticsearch, RequestsHttpConnection
from elasticsearch_dsl import Search
 
 
access_token = "4922602414-D1iU8xctvR5ztdCxeetGJz7Z9PkmvMy8p8dfweD"
access_token_secret = "zaZAl59XIRA2rIdTuqQrU11G8SlqCLi8OMHjZTXPe5un6"
consumer_key = "vbkSrMnZ6kSjarUHCM6PZ1SpN"
consumer_secret = "SitnA9jrMu0Zu5G2lzhMsZQVXyCzGNuHNU3OGgUJ96jmYMtTOw"

 
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
 
es = Elasticsearch(
  [
  'https://search-twitter-4gq7qku6bsxkouqneo3ktustqm.us-east-1.es.amazonaws.com'
  ],

  use_ssl=True,
  verify_certs=True,
  connection_class = RequestsHttpConnection

  )

 
class StreamListener_h(tweepy.StreamListener):
    status_wrapper = TextWrapper(width=60, initial_indent='    ', subsequent_indent='    ')
 
    def on_status(self, status):
        try:
            #print 'n%s %s' % (status.author.screen_name, status.created_at)
 
            json_data = status._json
            #print json_data['text']
 
            es.create(index="hillary",
                      doc_type="twitter",
                      body=json_data
                     )             
              
        except Exception, e:
            print e
            pass
 
streamer_h = tweepy.Stream(auth=auth, listener=StreamListener_h())
 
#Fill with your own Keywords bellow
 
streamer_h.filter(track = ['hillary', 'clinton'])

class StreamListener_t(tweepy.StreamListener):
    status_wrapper = TextWrapper(width=60, initial_indent='    ', subsequent_indent='    ')
 
    def on_status(self, status):
        try:
            #print 'n%s %s' % (status.author.screen_name, status.created_at)
 
            json_data = status._json
            #print json_data['text']
 
            es.create(index="trump",
                      doc_type="twitter",
                      body=json_data
                     )             
              
        except Exception, e:
            print e
            pass
 
streamer_t = tweepy.Stream(auth=auth, listener=StreamListener_t())
 
#Fill with your own Keywords bellow
 
streamer_t.filter(track = ['trump', 'donald'])

